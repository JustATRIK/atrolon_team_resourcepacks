#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    ivec3 rgb = ivec3(Color.rgb * 255.5); 

    if (rgb.r == 0 && rgb.g == 0 && rgb.b == 1) {
        int corner = gl_VertexID % 4;
        
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        
        vertexColor = vec4(0.0, 0.0, 0.0, 1.0);
        texCoord0 = UV0;
        
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;

        if (corner == 0) {
            gl_Position.x = -gl_Position.w;
            gl_Position.y = gl_Position.w;
        } else if (corner == 1) {
            gl_Position.x = -gl_Position.w;
            gl_Position.y = -gl_Position.w;
        } else if (corner == 2) {
            gl_Position.x = gl_Position.w;
            gl_Position.y = -gl_Position.w;
        } else if (corner == 3) {
            gl_Position.x = gl_Position.w;
            gl_Position.y = gl_Position.w;
        }
        
        gl_Position.z = -0.9 * gl_Position.w; 
    } else {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
        texCoord0 = UV0;
        
        sphericalVertexDistance = fog_spherical_distance(Position);
        cylindricalVertexDistance = fog_cylindrical_distance(Position);
    }
}